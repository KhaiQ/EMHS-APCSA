package gameClasses;

public class Obstacles {

}
