package gameClasses;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import game.Panel;
import gameClasses.Game;

public class Movement implements KeyListener
{

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
