package game;

public interface Character {

}
