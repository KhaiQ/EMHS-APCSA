package game;

public interface Game {

}
