package Graphics;

import javax.swing.JFrame;

public class Frame extends JFrame
{

	private static final long serialVersionUID = 1L;
	Panel p = new Panel();
	public Frame(String Title)
	{
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800,800);
		this.setTitle(Title);
		this.add(p);
	}
	
	public void update()
	{
		p.update();
		this.revalidate();
		this.repaint();
	}
}
