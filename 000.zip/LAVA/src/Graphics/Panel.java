package Graphics;

import java.awt.Graphics;

import javax.swing.JFrame;

import Classes.Obj;
import Classes.Player;

public class Panel extends JFrame
{
	private static final long serialVersionUID = 1L;
	private Player player;
	private Obj object;
	
	public Panel()
	{
		this.setVisible(true);
		this.setSize(800,800);
		this.setResizable(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void addPlayer(Player player)
	{
		this.player = player;
	}
	
	public void addObject(Obj o)
	{
		this.object = o;
	}
	
	public void paintComponent(Graphics g)
	{
		player.draw(g);
		object.draw(g);
	}
	
	public void update()
	{
		revalidate();
		repaint();
	}
}
