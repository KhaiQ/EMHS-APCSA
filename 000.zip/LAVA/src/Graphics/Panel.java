package Graphics;

import java.awt.Graphics;


import javax.swing.JPanel;

import Classes.Obj;
import Classes.Player;
import Classes.World;

public class Panel extends JPanel
{
	private static final long serialVersionUID = 1L;
	private Player player;
	private Obj object;
	private World world = new World();
	
	
	public Panel()
	{
		player = Player.player;
		this.setVisible(true);
	}
	
	public void addPlayer(Player player)
	{
		this.player = player;
	}
	
	public void addObject(Obj o)
	{
		this.object = o;
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		//object.draw(g);
		world.draw(g);
		player.draw(g);
	}
	
	public void update()
	{
		revalidate();
		repaint();
	}

	
}
