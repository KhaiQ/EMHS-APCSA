import Graphics.Panel;


public class Driver 
{
	private static Panel p = new Panel();
	private static boolean running = true;
	
	public static void main(String[] args)
	{
		while(running)
		{
			p.update();
		}
	}
}
