package Classes;

import java.awt.Graphics;

public class Player
{	
	public void draw(Graphics g)
	{
		
	}
	
	public void update()
	{
		
	}
}
