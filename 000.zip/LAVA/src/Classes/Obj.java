package Classes;

import java.awt.Graphics;

public class Obj
{
	
	public void draw(Graphics g)
	{
		
	}
	
	public void update()
	{
		
	}
}
